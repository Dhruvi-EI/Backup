import sys
sys.path.append('C:/Users/158410/PycharmProjects/pytestProject')
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.alert import Alert

class TestAmazon:
    def __init__(self, driver):
        self.driver = driver

    def launch_app_with_url(self,url):
        self.driver.get(url)

    def validate_logo(self,logo):
        self.driver.find_element(By.XPATH,logo)
        print(self.driver.title)
        time.sleep(2)

    def search_box(self,search,text):
        self.driver.find_element(By.XPATH,search).click()
        time.sleep(1)
        self.driver.find_element(By.XPATH,search).send_keys(text)
        time.sleep(2)

    def select(self,search):
        self.driver.find_element(By.XPATH,search).click()
        self.driver.implicitly_wait(10)

    def scroll(self,search):
        scroll=self.driver.find_element(By.XPATH,search)
        actions=ActionChains(self.driver)
        actions.move_to_element(scroll).perform()
        time.sleep(1)
        self.driver.find_element(By.XPATH, search).click()
        # self.driver.implicitly_wait(10)
        time.sleep(5)

    def scroll_to_cart(self,search):
        windows = self.driver.window_handles
        size = len(windows)
        parent_window = self.driver.current_window_handle
        for x in range(size):
            if windows[x] != parent_window:
                self.driver.switch_to.window(windows[x])
                time.sleep(3)
                break

        time.sleep(3)
        actions = ActionChains(self.driver)
        actions.move_to_element(self.driver.find_element(By.XPATH, search)).perform()
        time.sleep(2)

    def add_to_cart(self,search):
        self.driver.find_element(By.XPATH,search).click()
        self.driver.implicitly_wait(10)

    def go_to_cart(self,search):
        self.driver.find_element(By.XPATH,search).click()
        time.sleep(3)
