import sys
import pytest
sys.path.append('C:/Users/158410/PycharmProjects/pytestProject')
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from PageObject.Amazon import TestAmazon
from Locators import Amazon_Locators
import time
from selenium.webdriver.support.select import Select
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.alert import Alert

class TestAmazonApp:

    def test_amazon_logo(self):
        global driver
        driver=webdriver.Chrome()
        driver.implicitly_wait(5)
        obj=TestAmazon(driver)
        obj.launch_app_with_url("https://www.amazon.in/")
        driver.maximize_window()
        obj.validate_logo(Amazon_Locators.test_Amazon_Logo())

    def test_search_box(self):
        global driver
        driver = webdriver.Chrome()
        driver.implicitly_wait(5)
        obj = TestAmazon(driver)
        obj.launch_app_with_url("https://www.amazon.in/")
        driver.maximize_window()
        obj.search_box(Amazon_Locators.search_box(),"books")
        obj.select(Amazon_Locators.select_from_search())
        obj.scroll(Amazon_Locators.select_book())
        obj.scroll_to_cart(Amazon_Locators.scroll_to_cart_button())
        obj.add_to_cart(Amazon_Locators.add_to_cart())
        # obj.go_to_cart(Amazon_Locators.go_to_cart())