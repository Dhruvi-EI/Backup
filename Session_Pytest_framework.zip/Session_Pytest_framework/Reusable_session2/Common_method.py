from selenium import webdriver
from selenium.webdriver.chrome.service import Service as Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
#interact python with xml........
from xml.dom import minidom
#to path the current project need this...
from pathlib import Path
import time

def readXmlAsPerNode(your_test_param):
    #it will give path of current project
    #first_parse_xml=minidom.parse(str(Path(__file__).parent.parent)+"/TestData.xml")
    first_parse_xml = minidom.parse("C:/Users/158202/PycharmProjects/Session/TestData.xml")
    data= first_parse_xml.getElementsByTagName(your_test_param)[0]

    return data.firstChild.data


def validatePrimaryMenusByXpath(linkName):
    return "(//a[contains(.,'"+linkName+"')])[1]"
