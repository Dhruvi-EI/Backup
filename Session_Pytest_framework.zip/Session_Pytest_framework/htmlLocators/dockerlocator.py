def docker_logo():
    return "//li[@class='logo']/a"
def docker_getStarted():
    return "(//a[text()='Get Started'])[1]"
def docker_all_links():
    return "//a"
def docker_headerMenu(i):
    return "//ul[@class='nav']//a[text()='" + i + "']"
def docker_hoverclick():
    return "(//a[contains(.,'Developers')])[1]","(//a[contains(.,'Community')])[1]"