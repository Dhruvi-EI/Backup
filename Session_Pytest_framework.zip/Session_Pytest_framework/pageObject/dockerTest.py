import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from Reusable_session2 import Common_method
from htmlLocators import dockerlocator
class DockerTest:
    def __init__(self,driver):
        self.driver=driver

    def launch_with_url(self,url):
        self.driver.get(url)
        self.driver.implicitly_wait(10)
        self.driver.maximize_window()

    def docker_logoValidation(self,xpath):
        print(self.driver.title)
        Xpath = self.driver.find_elements(By.XPATH, xpath)
        assert len(Xpath) > 0

    def docker_HoverAndClickDevelopers(self,xpath1,xpath2):
        ele =self.driver.find_element(By.XPATH,xpath1)
        ActionChains(self.driver).move_to_element(ele).perform()
        time.sleep(3)
        self.driver.find_element(By.XPATH,xpath2).click()
        time.sleep(3)
        if "community" in self.driver.current_url:
            print("User Passed Sucess !!")
        else:
            print("User Unable........")


    def docker_getStarted_validation(self,xpath):
        self.driver.find_element(By.XPATH,xpath).click()
        time.sleep(2)

    def docker_header_links(self):
        list_of_header = Common_method.readXmlAsPerNode("dockerHeader")
        value = list_of_header.split(",")
        for i in value:
            if self.driver.find_element(By.XPATH,dockerlocator.docker_headerMenu(i)).is_displayed():
                    print("Header Got .........>>", i)

    def print_allLinks(self):
        allLinks=self.driver.find_elements(By.XPATH,dockerlocator.docker_all_links())
        print(len(allLinks))
        for i in allLinks:
            print(i.text)
