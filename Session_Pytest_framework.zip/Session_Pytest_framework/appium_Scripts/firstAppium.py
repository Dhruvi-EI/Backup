from appium import webdriver
from appium.webdriver.common.appiumby import AppiumBy


class TestDockerAppium:
    capabilities ={
        "deviceName":"RedMi Note 11 Pro +",
        "platformName":"Android",
        "version":"11.0",
        "browserName":"chrome",
        "udid":"emulator-5554"
    }
    def launch_Appium_Driver(self):
        global driver
        driver = webdriver.Remote("http://localhost:4723/wd/hub", self.capabilities)
        driver.get("https://www.docker.com/")

    def test_docker_logo(self):
        docker_logo=driver.find_element(AppiumBy.XPATH,"//li[@class='logo']")
        if docker_logo.is_displayed():
            print("Docker Logo is present")
    
        else:
            print("Logo not present")

    def close_app(self):
        driver.quit()        


obj = TestDockerAppium()
obj.launch_Appium_Driver()
obj.test_docker_logo()  
obj.close_app() 

