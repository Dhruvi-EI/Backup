from appium import webdriver
import time
from appium.webdriver.common.appiumby import AppiumBy


class TestDockerAppium:
    capabilities ={
        "deviceName":"RedMi Note 11 Pro +",
        "platformName":"Android",
        "version":"11.0",
        "udid":"emulator-5554",
        "app":"C:/Users/158202/Downloads/naukri-com-17-1.apk"
    }
    #Android Native App in real device using  Chrome...
    def launch_Appium_Driver(self):
        global driver
        driver = webdriver.Remote("http://localhost:4723/wd/hub", self.capabilities)
        time.sleep(2)
        driver.update_settings({"waitForIdleTimeout":1000})

    
    
    def test_naukri_link(self):
        docker_register=driver.find_element(AppiumBy.ID,"naukriApp.appModules.login:id/textViewNormalLogin")
        if docker_register.is_displayed():
            driver.find_element(AppiumBy.ID,"naukriApp.appModules.login:id/textViewNormalLogin").click()
            time.sleep(3)
            driver.find_element(AppiumBy.ID,"naukriApp.appModules.login:id/iv_back").click()
            time.sleep(2)
            #search naukri
            search_element=driver.find_element(AppiumBy.ID,"naukriApp.appModules.login:id/editTextSearch")
            search_element.send_keys("Accountant")
            time.sleep(3)
            search_element.click()
            time.sleep(3)
        else:
            print("not done")

    def validate_first_image(self):
        naukri_logo=driver.find_element(AppiumBy.XPATH,"//android.widget.TextView[@text='Get started on Naukri']")
        if naukri_logo.is_displayed():
            print("Logo Image Present!!")
        time.sleep(2)
        driver.find_element(AppiumBy.ID,"naukriApp.appModules.login:id/iv_back").click()
        time.sleep(2)

    
    def validate_form(self):
         
         driver.find_element(AppiumBy.ID,"naukriApp.appModules.login:id/textViewNormalLogin").click()
         time.sleep(3)
         driver.find_element(AppiumBy.ID,"naukriApp.appModules.login:id/iv_back").click()
         time.sleep(2)
         #click register
         driver.find_element(AppiumBy.XPATH,"//android.widget.TextView[@text='Register']").click()
         time.sleep(2)
         #inside register
         driver.find_element(AppiumBy.ID,"naukriApp.appModules.login:id/resman_next_button").click()
         time.sleep(2)



    

    
    def close_app(self):
        driver.quit()        

    
obj = TestDockerAppium()
obj.launch_Appium_Driver()
#obj.test_naukri_link()
#obj.test_docker_logo()  
#obj.validate_first_image()
obj.validate_form()
obj.close_app() 

