import json
import time
import sys
sys.path.append('C:/Users/158202/PycharmProjects/Session_Pytest_framework')
from selenium import webdriver
import pytest
from selenium.webdriver.chrome.service import Service as Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from webdriver_manager.firefox import GeckoDriverManager

#appium
from appium import webdriver

@pytest.fixture()
def browser(request):
    print("initial chrome driver")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    request.instance.driver =driver
    driver.maximize_window()

    yield driver
    driver.quit()


@pytest.fixture(scope="class")
def browser_cls(request):
    print("initial chrome driver")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    request.cls.driver =driver
    driver.maximize_window()

    yield driver
    driver.quit()


def pytest_addoption(parser):
    parser.addoption("--browser", action="store",help="input browser")

@pytest.fixture()
def params(request):
    params={}
    params['browser']= request.config.getoption('--browser')
    return params

@pytest.fixture()
def crossbrowsertesting(request, params):
    print("initiating chrome driver")
    driver = ""
    if params["browser"]=="chrome":
        driver=webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    if params["browser"] == "firefox":
        driver = webdriver.Firefox(service=Service(GeckoDriverManager().install()))
    request.cls.driver =driver
    driver.maximize_window()

    yield driver
    driver.quit()

#pip install pytest-xdist

# to get data from json
@pytest.fixture()
def jsonData():
    with open('testData/testData.json')as config_file:
        data=json.load(config_file)
    return data

@pytest.fixture()
def appiumdriver(request):
    print("initial chrome driver")
    
    capabilities ={
        "deviceName":"RedMi Note 11 Pro +",
        "platformName":"Android",
        "platformVersion":"11.0",
        "browserName":"chrome",
        "udid":"emulator-5554"
    }

    driver = webdriver.Remote("https://localhost:4723/wd/hub , capabilities")
    request.instance.driver =driver
    driver.maximize_window()

    yield driver
    driver.quit()