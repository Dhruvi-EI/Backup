import time
import sys
sys.path.append('C:/Users/158202/PycharmProjects/Session_Pytest_framework')
from selenium import webdriver
import pytest
from selenium.webdriver.chrome.service import Service as Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from pageObject.googleHome import Google_Home
from htmlLocators import googlelocator


@pytest.mark.usefixtures("crossbrowsertesting")
class TestGoogleApp_1:
    @pytest.mark.smoke
    def test_google_Logo(self,jsonData):
        obj1=Google_Home(self.driver)
        obj1.launch_app_with_url(jsonData['url_google'])
        obj1.google_logo_validation(googlelocator.google_logo())
    @pytest.mark.regression
    def test_google_Search(self):
        obj1 = Google_Home(self.driver)
        obj1.launch_app_with_url("https://www.google.com/")
        obj1.google_search_type(googlelocator.google_search_text_box(),"Selenium WebDriver")

    @pytest.mark.regression
    def test_google_title(self):
        obj1 = Google_Home(self.driver)
        obj1.launch_app_with_url("https://www.google.com/")
        obj1.validate_google_title("Google")

    def test_heroku_frame(self):
        obj1 = Google_Home(self.driver)
        obj1.launch_app_with_url("https://the-internet.herokuapp.com/iframe")
        obj1.heroku_frame(googlelocator.heroku_frame(),"Shubham is good Boy")



