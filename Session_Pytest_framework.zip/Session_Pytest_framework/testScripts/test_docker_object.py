import time

import pytest
from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from pageObject.dockerTest import DockerTest
from htmlLocators import dockerlocator
import sys
sys.path.append('C:/Users/158202/PycharmProjects/Session_Pytest_framework')
from selenium.webdriver.common.by import By

@pytest.mark.usefixtures("crossbrowsertesting")
#@pytest.mark.usefixtures("browser_cls")
class TestDockerWebApp:


    def test_docker_logo(self):

        ob1=DockerTest(self.driver)
        ob1.launch_with_url("https://www.docker.com/")

        ob1.docker_logoValidation(dockerlocator.docker_logo())
        time.sleep(2)
        #assert len(logo)>0
        #driver.quit()
    def test_docker_getStarted(self):

        ob1 = DockerTest(self.driver)
        ob1.launch_with_url("https://www.docker.com/")
        ob1.docker_getStarted_validation(dockerlocator.docker_getStarted())
        time.sleep(3)

    '''
    def test_docker_HoverAndClickDevelopers(self,browser):
        ob1 = DockerTest(browser)
        ob1.launch_with_url("https://www.docker.com/")
        xpath1,xpath2=dockerlocator.docker_hoverclick()
        ob1.docker_HoverAndClickDevelopers(xpath1,xpath2)

        time.sleep(3)
    '''

    '''
    def test_PrintAllLinks(self,browser):
        #driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        obj1 = DockerTest(browser)
        obj1.launch_with_url("https://www.docker.com/")
        obj1.print_allLinks()
        time.sleep(2)

    def test_HeaderMenuLinks(self, browser):
        # driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        obj1 = DockerTest(browser)
        obj1.launch_with_url("https://www.docker.com/")
        obj1.docker_header_links()
        time.sleep(2)

    '''



