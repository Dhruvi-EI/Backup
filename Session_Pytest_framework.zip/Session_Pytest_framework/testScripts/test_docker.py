import time

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import sys
sys.path.append('C:/Users/158202/PycharmProjects/Session_Pytest_framework')
from selenium.webdriver.common.by import By

def test_docker_logo():
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.get("https://www.docker.com/")
    driver.maximize_window()
    driver.implicitly_wait(10)
    logo=driver.find_elements(By.XPATH,"//li[@class='logo']/a")
    time.sleep(2)
    assert len(logo)>0
    driver.quit()
def test_docker_getStarted():
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.get("https://www.docker.com/")
    driver.maximize_window()
    driver.implicitly_wait(10)
    driver.find_element(By.XPATH, "(//a[text()='Get Started'])[1]").click()
    time.sleep(3)
    driver.quit()

def test_docker_HoverAndClickDevelopers():
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.get("https://www.docker.com/")
    driver.maximize_window()
    driver.implicitly_wait(10)
    time.sleep(2)
    ele = driver.find_element(By.XPATH, "(//a[contains(.,'Developers')])[1]")
    ActionChains(driver).move_to_element(ele).perform()
    time.sleep(3)
    driver.find_element(By.XPATH, "(//a[contains(.,'Community')])[1]").click()
    driver.implicitly_wait(10)
    if "community" in driver.current_url:
        print("User Passed Sucess !!")

    else:
        print("User Unable........")
    time.sleep(3)





