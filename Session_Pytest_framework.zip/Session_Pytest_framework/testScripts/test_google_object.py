import time
import sys
sys.path.append('C:/Users/158202/PycharmProjects/Session_Pytest_framework')
from selenium import webdriver
import pytest
from selenium.webdriver.chrome.service import Service as Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from pageObject.googleHome import Google_Home
from htmlLocators import googlelocator
class TestGoogleApp:
    @pytest.mark.smoke
    def test_google_Logo(self,browser):
        obj1=Google_Home(browser)
        obj1.launch_app_with_url("https://www.google.com/")
        obj1.google_logo_validation(googlelocator.google_logo())
    @pytest.mark.regression
    def test_google_Search(self,browser):
        obj1 = Google_Home(browser)
        obj1.launch_app_with_url("https://www.google.com/")
        obj1.google_search_type(googlelocator.google_search_text_box(),"Selenium WebDriver")

    @pytest.mark.regression
    def test_google_title(self,browser):
        obj1 = Google_Home(browser)
        obj1.launch_app_with_url("https://www.google.com/")
        obj1.validate_google_title("Google")



